    #   Como Executar

    python3 server.py
    python3 client.py

    Execute cada um destes comandos a cima em uma aba diferente do terminal 
    
    # Bibliotecas usadas

    threading: usada para implementar threads (https://docs.python.org/3/library/threading.html)
    socket: usada para implementar sockets (https://docs.python.org/3/library/socket.html) 
    os: usada para implementar funcionalidades de  sistema operacional (https://docs.python.org/3/library/os.html)

    # Exemplo de uso

    Client: ADDFILE file.txt
